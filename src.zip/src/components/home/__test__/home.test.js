import React from "react";
// import { createStore } from "redux";
import { Provider } from "react-redux";
import store from '../../../state/index';
import Home from '../home';
import { render } from "@testing-library/react";
import { StaticRouter } from "react-router-dom";

it("MAIN START BUTTON", () => {
    const { getByTestId, getByText } = render(<Provider store={store}><StaticRouter><Home /></StaticRouter></Provider>);
    expect(getByTestId("main-button")).toBeTruthy();
});

it("RENDER START BUTTON", () => {
    const { getByTestId, getByText } = render(<Provider store={store}><StaticRouter><Home /></StaticRouter></Provider>);
    expect(getByTestId("button-start")).toHaveTextContent("Start");
});